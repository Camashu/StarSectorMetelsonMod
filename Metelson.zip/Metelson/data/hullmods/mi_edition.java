package data.hullmods;

import java.util.HashMap;
import java.util.Map;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.HullModFleetEffect;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;

public class mi_edition extends BaseHullMod { //implements HullModFleetEffect {

	/* Militarized Auxiliary 
	 * Basically take a civilian hull, bring it up to military standards. (More or less.)
	 * - military sensor profile/detection (handled in skin by removing civ hull)
	 * - more OP (handled in skin)
	 * - slightly better flux handling
	 * - slightly better armour
	 * - slightly better speed/maneuver
	 * - 
	 */
	private static final float DISSIPATION_MULT = 1.1f;
	
	
	private static Map mag = new HashMap();
	static {
		mag.put(HullSize.FRIGATE, 15f);
		mag.put(HullSize.DESTROYER, 20f);
		mag.put(HullSize.CRUISER, 25f);
		mag.put(HullSize.CAPITAL_SHIP, 35f);
	}
	/*StatBonus getFleetwideMaxBurnMod();   Burn enhance by some percent in Astroid belt*/
	public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
		
		// Slightly better armour and hull
		stats.getArmorBonus().modifyPercent(id, (Float) mag.get(hullSize));
		stats.getHullBonus().modifyPercent(id, (Float) mag.get(hullSize));
                
		// 10% better flux stats
		stats.getFluxDissipation().modifyMult(id, DISSIPATION_MULT);
		


		
	}
	
	public String getDescriptionParam(int index, HullSize hullSize) {
		if (index == 0) return "" + ((Float) mag.get(HullSize.FRIGATE)).intValue();
		if (index == 1) return "" + ((Float) mag.get(HullSize.DESTROYER)).intValue();
		if (index == 2) return "" + ((Float) mag.get(HullSize.CRUISER)).intValue();
		if (index == 3) return "" + ((Float) mag.get(HullSize.CAPITAL_SHIP)).intValue();
		if (index == 4) return "" + (int) ((DISSIPATION_MULT - 1f) * 100f);
		return null;
		//if (index == 0) return "" + ((Float) mag.get(hullSize)).intValue();
		//return null;
	}


}
