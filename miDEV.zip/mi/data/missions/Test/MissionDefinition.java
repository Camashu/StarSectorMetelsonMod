package data.missions.Test;
// Note to self: THIS IS TEST MISSION, IF TO TEST SHIPS MUST PUT SHIPS HERE.
import java.util.List;

import com.fs.starfarer.api.campaign.CargoAPI.CrewXPLevel;
import com.fs.starfarer.api.combat.BaseEveryFrameCombatPlugin;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.fleet.FleetGoal;
import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.mission.FleetSide;
import com.fs.starfarer.api.mission.MissionDefinitionAPI;
import com.fs.starfarer.api.mission.MissionDefinitionPlugin;

public class MissionDefinition implements MissionDefinitionPlugin {

    
        @Override
	public void defineMission(MissionDefinitionAPI api) {

		
		// Set up the fleets so we can add ships and fighter wings to them.
		// In this scenario, the fleets are attacking each other, but
		// in other scenarios, a fleet may be defending or trying to escape
		api.initFleet(FleetSide.PLAYER, "MSV.", FleetGoal.ATTACK, false, 5);
		api.initFleet(FleetSide.ENEMY, "HSS", FleetGoal.ATTACK, true);

		// Set a small blurb for each fleet that shows up on the mission detail and
		// mission results screens to identify each side.
		api.setFleetTagline(FleetSide.PLAYER, "Metelsons Industries testing fleet");
		api.setFleetTagline(FleetSide.ENEMY, "Hegemony convoy and assisting patrol force");
		
		// These show up as items in the bulleted list under 
		// "Tactical Objectives" on the mission detail screen
		api.addBriefingItem("FOR TEST PURPOSE ONLY!");
		
		// Set up the player's fleet.  Variant names come from the
		// files in data/variants and data/variants/fighters
                
                // FleetMemberAPI addToFleet(FleetSide side, String variantId, FleetMemberType type, #String shipName, boolean isFlagship, #CrewXPLevel level);
                api.addToFleet(FleetSide.PLAYER, "mi_pala_standard", FleetMemberType.SHIP, false, CrewXPLevel.ELITE);
                api.addToFleet(FleetSide.PLAYER, "mi_cavos_standard", FleetMemberType.SHIP, false, CrewXPLevel.ELITE);
                api.addToFleet(FleetSide.PLAYER, "mi_roma_standard", FleetMemberType.SHIP, false, CrewXPLevel.ELITE);
                api.addToFleet(FleetSide.PLAYER, "mi_mite_standard", FleetMemberType.SHIP, false, CrewXPLevel.ELITE);
		api.addToFleet(FleetSide.PLAYER, "mi_acutor_standard", FleetMemberType.SHIP, false, CrewXPLevel.ELITE);
		api.addToFleet(FleetSide.PLAYER, "mi_vigilance_standard", FleetMemberType.SHIP, false, CrewXPLevel.ELITE);
		api.addToFleet(FleetSide.PLAYER, "mi_wolf_standard", FleetMemberType.SHIP, false, CrewXPLevel.ELITE);
		api.addToFleet(FleetSide.PLAYER, "mi_gadfar_standard", FleetMemberType.SHIP, false, CrewXPLevel.ELITE);
                api.addToFleet(FleetSide.PLAYER, "mi_rastrum_standard", FleetMemberType.SHIP, false, CrewXPLevel.ELITE);
                api.addToFleet(FleetSide.PLAYER, "mi_mantarn_standard", FleetMemberType.SHIP, false, CrewXPLevel.ELITE);
                api.addToFleet(FleetSide.PLAYER, "mi_varingur_standard", FleetMemberType.SHIP, false, CrewXPLevel.ELITE);
                api.addToFleet(FleetSide.PLAYER, "mi_enforcer_standard", FleetMemberType.SHIP, false, CrewXPLevel.ELITE);
                api.addToFleet(FleetSide.PLAYER, "mi_securi_standard", FleetMemberType.SHIP, false, CrewXPLevel.ELITE);
                api.addToFleet(FleetSide.PLAYER, "mi_glima_standard", FleetMemberType.SHIP, false, CrewXPLevel.ELITE);
				api.addToFleet(FleetSide.PLAYER, "mi_actelh35_standard", FleetMemberType.SHIP, false, CrewXPLevel.ELITE);
                
                api.addToFleet(FleetSide.PLAYER, "mi_grancursor_standard", FleetMemberType.SHIP, false, CrewXPLevel.ELITE);
                api.addToFleet(FleetSide.PLAYER, "mi_thrudgelmir_CS", FleetMemberType.SHIP, false, CrewXPLevel.ELITE);
                

                
                        api.addToFleet(FleetSide.PLAYER, "negl_wing", FleetMemberType.FIGHTER_WING, false, CrewXPLevel.ELITE);	
			api.addToFleet(FleetSide.PLAYER, "obex_wing", FleetMemberType.FIGHTER_WING, false, CrewXPLevel.ELITE);	
			api.addToFleet(FleetSide.PLAYER, "golgata_wing", FleetMemberType.FIGHTER_WING, false, CrewXPLevel.ELITE);	
			api.addToFleet(FleetSide.PLAYER, "grudiver_wing", FleetMemberType.FIGHTER_WING, false, CrewXPLevel.ELITE);	



		// Set up the enemy fleet.
		api.addToFleet(FleetSide.ENEMY, "mi_thrudgelmir_standard", FleetMemberType.SHIP, false);
		api.addToFleet(FleetSide.ENEMY, "buffalo2_FS", FleetMemberType.SHIP, false);
		api.addToFleet(FleetSide.ENEMY, "broadsword_wing", FleetMemberType.FIGHTER_WING, false);
		
		api.addToFleet(FleetSide.ENEMY, "enforcer_Outdated", FleetMemberType.SHIP, false);
		api.addToFleet(FleetSide.ENEMY, "enforcer_Assault", FleetMemberType.SHIP, false);
                api.addToFleet(FleetSide.ENEMY, "enforcer_Assault", FleetMemberType.SHIP, false);
		api.addToFleet(FleetSide.ENEMY, "lasher_CS", FleetMemberType.SHIP, false);
		api.addToFleet(FleetSide.ENEMY, "lasher_CS", FleetMemberType.SHIP, false);
		
		api.addToFleet(FleetSide.ENEMY, "broadsword_wing", FleetMemberType.FIGHTER_WING, false);
		api.addToFleet(FleetSide.ENEMY, "talon_wing", FleetMemberType.FIGHTER_WING, false);
		api.addToFleet(FleetSide.ENEMY, "talon_wing", FleetMemberType.FIGHTER_WING, false);
                api.addToFleet(FleetSide.ENEMY, "condor_FS", FleetMemberType.SHIP, false);
		
		// Set up the map.
		float width = 24000f;
		float height = 18000f;
		api.initMap((float)-width/2f, (float)width/2f, (float)-height/2f, (float)height/2f);
		
		float minX = -width/2;
		float minY = -height/2;
		
		api.addNebula(minX + width * 0.5f - 300, minY + height * 0.5f, 1000);
		api.addNebula(minX + width * 0.5f + 300, minY + height * 0.5f, 1000);
		
		for (int i = 0; i < 5; i++) {
			float x = (float) Math.random() * width - width/2;
			float y = (float) Math.random() * height - height/2;
			float radius = 100f + (float) Math.random() * 400f; 
			api.addNebula(x, y, radius);
		}
		
		// Add an asteroid field
		api.addAsteroidField(minX + width/2f, minY + height/2f, 0, 8000f,
								20f, 70f, 100);
		
		api.addPlugin(new BaseEveryFrameCombatPlugin() {
			public void init(CombatEngineAPI engine) {
				engine.getContext().setStandoffRange(6000f);
			}
			public void advance(float amount, List events) {
			}
		});
		
	}

}




