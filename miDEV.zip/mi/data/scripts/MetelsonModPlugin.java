package data.scripts;

import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;

import data.scripts.world.MetiGen;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;


public class MetelsonModPlugin extends BaseModPlugin
{
    private static void initMetelson() 
        {
            new MetiGen().generate(Global.getSector());
        }

    @Override
    public void onNewGame()
    {
        try {  
            //Got Exerelin, so load Exerelin  
            Class<?> def = Global.getSettings().getScriptClassLoader().loadClass("exerelin.campaign.SectorManager");  
            Method method;  
            try {  
                method = def.getMethod("getCorvusMode");  
                Object result = method.invoke(def);  
                if ((boolean)result == true)  
                {  
                    // Exerelin running in Corvus mode, go ahead and generate our sector  
                    initMetelson();
                }  
            } catch (NoSuchMethodException | SecurityException | IllegalAccessException | IllegalArgumentException |  
                     InvocationTargetException ex) {  
                // check failed, do nothing  
            }  
              
        } catch (ClassNotFoundException ex) {  
            // Exerelin not found so continue and run normal generation code  
            initMetelson();
        }  
    }
}
