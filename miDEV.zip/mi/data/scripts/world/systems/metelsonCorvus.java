package data.scripts.world.systems;

import com.fs.starfarer.api.campaign.*;
import java.util.ArrayList;
import java.util.Arrays;

// Referenced classes of package data.scripts.world.systems:
//            Metelson_markets

public class metelsonCorvus
{

    public metelsonCorvus()
    {
    }

    public void generate(SectorAPI sector)
    {
        StarSystemAPI system = sector.getStarSystem("Corvus");
        SectorEntityToken MIdepo1 = system.addCustomEntity("metelsonCorvus", "MI ShipPort", "station_side04", "metelson");
        MIdepo1.setCircularOrbitPointingDown(system.getEntityById("asharu"), 115F, 600F, 100F);
        MIdepo1.setCustomDescriptionId(null);
        com.fs.starfarer.api.campaign.econ.MarketAPI MIshipPort = Metelson_markets.addMarketplace("metelson", MIdepo1, null, "MI ShipPort", 3, new ArrayList(Arrays.asList(new String[] {
            "trade_center", "orbital_station", "outpost", "population_2"
        })), new ArrayList(Arrays.asList(new String[] {
            "open_market", "generic_military", "black_market", "storage"
        })), 0.3F);
    }
}
