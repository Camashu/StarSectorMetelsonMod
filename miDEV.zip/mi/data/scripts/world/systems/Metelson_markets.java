
package data.scripts.world.systems;

import com.fs.starfarer.api.FactoryAPI;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.econ.EconomyAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.combat.MutableStat;
import java.util.*;

public class Metelson_markets
{

    public Metelson_markets()
    {
    }

    public static MarketAPI addMarketplace(String factionID, SectorEntityToken primaryEntity, ArrayList connectedEntities, String name, int size, ArrayList marketConditions, ArrayList submarkets, float tarrif)
    {
        EconomyAPI globalEconomy = Global.getSector().getEconomy();
        String planetID = primaryEntity.getId();
        String marketID = planetID;
        MarketAPI newMarket = Global.getFactory().createMarket(marketID, name, size);
        newMarket.setFactionId(factionID);
        newMarket.setPrimaryEntity(primaryEntity);
        newMarket.setBaseSmugglingStabilityValue(0);
        newMarket.getTariff().modifyFlat("generator", tarrif);
        if(null != submarkets)
        {
            String market;
            for(Iterator i$ = submarkets.iterator(); i$.hasNext(); newMarket.addSubmarket(market))
                market = (String)i$.next();

        }
        String condition;
        for(Iterator i$ = marketConditions.iterator(); i$.hasNext(); newMarket.addCondition(condition))
            condition = (String)i$.next();

        if(null != connectedEntities)
        {
            SectorEntityToken entity;
            for(Iterator i$ = connectedEntities.iterator(); i$.hasNext(); newMarket.getConnectedEntities().add(entity))
                entity = (SectorEntityToken)i$.next();

        }
        globalEconomy.addMarket(newMarket);
        primaryEntity.setMarket(newMarket);
        primaryEntity.setFaction(factionID);
        if(null != connectedEntities)
        {
            SectorEntityToken entity;
            for(Iterator i$ = connectedEntities.iterator(); i$.hasNext(); entity.setFaction(factionID))
            {
                entity = (SectorEntityToken)i$.next();
                entity.setMarket(newMarket);
            }

        }
        return newMarket;
    }
}
