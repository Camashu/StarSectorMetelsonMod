package data.scripts.world;


import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.RepLevel;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;

import data.scripts.world.systems.Rock;
import data.scripts.world.systems.metelsonCorvus;

public class MetiGen {

	public void generate(SectorAPI sector) {
            initFactionRelationships(sector);
            new Rock().generate(sector);
            (new metelsonCorvus()).generate(sector);
                                               
        }

    public static void initFactionRelationships(SectorAPI sector) {

	FactionAPI metelson = sector.getFaction("metelson");	
	
        FactionAPI hegemony = sector.getFaction(Factions.HEGEMONY);
        FactionAPI tritachyon = sector.getFaction(Factions.TRITACHYON);
        FactionAPI pirates = sector.getFaction(Factions.PIRATES);
        FactionAPI independent = sector.getFaction(Factions.INDEPENDENT);
        FactionAPI kol = sector.getFaction(Factions.KOL);
        FactionAPI church = sector.getFaction(Factions.LUDDIC_CHURCH);
        FactionAPI path = sector.getFaction(Factions.LUDDIC_PATH);
        FactionAPI player = sector.getFaction(Factions.PLAYER);
        FactionAPI diktat = sector.getFaction(Factions.DIKTAT);
        
        //modded factions  
        FactionAPI sra = sector.getFaction("shadow_industry");  
        FactionAPI pirateAnar = sector.getFaction("pirateAnar");  
        FactionAPI mayorate = sector.getFaction("mayorate");  
        FactionAPI ice = sector.getFaction("sun_ice");  
        FactionAPI ici = sector.getFaction("sun_ici");  
        FactionAPI citadel = sector.getFaction("citadeldefenders");  
        FactionAPI II = sector.getFaction("interstellarimperium");
        FactionAPI exi = sector.getFaction("exigency");
        FactionAPI brdy = sector.getFaction("blackrock_driveyards");
        FactionAPI lions = sector.getFaction("lions_guard");
        FactionAPI ahr = sector.getFaction("exipirated");
  
        if (sra != null) {  
            metelson.setRelationship(sra.getId(), RepLevel.WELCOMING);
        }  

        if (pirateAnar != null) {  
            metelson.setRelationship(pirateAnar.getId(), RepLevel.HOSTILE); 
        }  

        if (mayorate != null) {  
            metelson.setRelationship(mayorate.getId(), RepLevel.SUSPICIOUS);
        }  

        if (ice != null) {  
            metelson.setRelationship(ice.getId(), RepLevel.NEUTRAL);
        }  

        if (ici != null) {  
            metelson.setRelationship(ici.getId(), RepLevel.NEUTRAL);
        }  

        if (citadel != null) {  
            metelson.setRelationship(citadel.getId(), RepLevel.FAVORABLE);
        }  
          
        if (II != null) {  
            metelson.setRelationship(II.getId(), RepLevel.NEUTRAL);
        }  
        
        if (ahr != null) {  
            metelson.setRelationship(ahr.getId(), RepLevel.FAVORABLE);

        } 
        
        if (exi != null) {  
            metelson.setRelationship(exi.getId(), RepLevel.SUSPICIOUS); 
        } 
        
        player.setRelationship(metelson.getId(), 0);

        metelson.setRelationship(hegemony.getId(), RepLevel.FAVORABLE);
        metelson.setRelationship(pirates.getId(), RepLevel.HOSTILE);
        metelson.setRelationship(diktat.getId(), RepLevel.FAVORABLE);
        metelson.setRelationship(tritachyon.getId(), RepLevel.HOSTILE);
        metelson.setRelationship(independent.getId(), RepLevel.FAVORABLE);

	pirates.setRelationship(metelson.getId(), RepLevel.HOSTILE);
        tritachyon.setRelationship(metelson.getId(), RepLevel.HOSTILE);
    }
}
