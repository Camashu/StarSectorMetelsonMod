package data.shipsystems.scripts;
    
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;

public class thrudrostor extends BaseShipSystemScript {

    /**
     *
     */
     public static final float INCOMING_DAMAGE_MULT = 0.60f;

	
	public void apply(MutableShipStatsAPI stats, String id, State state, float effectLevel) {
		effectLevel = 1f;
		stats.getMaxSpeed().modifyFlat(id, 15f * effectLevel);
		stats.getAcceleration().modifyFlat(id, 100f * effectLevel);
		stats.getHullDamageTakenMult().modifyMult(id, 1f - (1f - INCOMING_DAMAGE_MULT) * effectLevel);
		stats.getArmorDamageTakenMult().modifyMult(id, 1f - (1f - INCOMING_DAMAGE_MULT) * effectLevel);
		stats.getEmpDamageTakenMult().modifyMult(id, 1f - (1f - INCOMING_DAMAGE_MULT) * effectLevel);
                

			//stats.getAcceleration().modifyPercent(id, 200f * effectLevel);
		}
		
	public void unapply(MutableShipStatsAPI stats, String id) {
	//	stats.getHullDamageTakenMult().unmodify(id);
	//	stats.getArmorDamageTakenMult().unmodify(id);
	//	stats.getEmpDamageTakenMult().unmodify(id);
               
		stats.getMaxSpeed().unmodify(id);
		stats.getMaxTurnRate().unmodify(id);
		stats.getTurnAcceleration().unmodify(id);
		stats.getAcceleration().unmodify(id);
		stats.getDeceleration().unmodify(id);
 
	}
	
	
        public StatusData getStatusData(int index, State state, float effectLevel) {
		if (index == 0) {
			return new StatusData("Damage Cut by 60%", false);
		}
        return null;
	}
	
	/*public StatusData getStatusData(int index, State state, float effectLevel) {
		effectLevel = 1f;
		float percent = (1f - INCOMING_DAMAGE_MULT) * effectLevel * 100;
		if (index == 0) {
			return new StatusData((int) percent + "% less damage taken", false);
			}
		return null;
	} */
}