package data.scripts.world.systems;

import java.awt.Color;
import java.util.List;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.OrbitAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.CargoAPI.CrewXPLevel;
import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;

public class Rock {

	public void generate(SectorAPI sector) {
		StarSystemAPI system = sector.createStarSystem("Rock");
		LocationAPI hyper = Global.getSector().getHyperspace();
		
		system.setBackgroundTextureFilename("graphics/backgrounds/background4.jpg");
		
                SectorEntityToken rock_nebula = Misc.addNebulaFromPNG("data/campaign/terrain/rock_nebula.png",
				  0, 0, // center of nebula
				  system, // location to add to
				  "terrain", "nebula_amber", // "nebula_blue", // texture to use, uses xxx_map for map
				  4, 4); // number of cells in texture
		// create the star and generate the hyperspace anchor for this system
		PlanetAPI star = system.initStar("rock", // unique id for star
										 "star_red", // id in planets.json
										 150f,		// radius (in pixels at default zoom)
										 200); // corona radius, from star edge
		
		system.setLightColor(new Color(255, 210, 200)); // light color in entire system, affects all entities
		star.setCustomDescriptionId("star_red_rock");
		
                
                /*
		 * addAsteroidBelt() parameters:
		 * 1. What the belt orbits
		 * 2. Number of asteroids
		 * 3. Orbit radius
		 * 4. Belt width
		 * 6/7. Range of days to complete one orbit. Value picked randomly for each asteroid. 
		 */
                
                
                //Dustrings and such
                 system.addRingBand(star, "misc", "rings1", 256F, 2, Color.white, 256F, 2000F, 80F);
                 system.addRingBand(star, "misc", "rings1", 256F, 3, Color.white, 256F, 1400F, 100F);
                 system.addRingBand(star, "misc", "rings1", 256F, 2, Color.white, 256F, 1600F, 130F);
                 system.addRingBand(star, "misc", "rings2", 256F, 3, Color.white, 356F, 1000F, 80F);
                 system.addRingBand(star, "misc", "rings2", 256F, 2, Color.white, 556F, 2200F, 80F);
                 system.addRingBand(star, "misc", "rings2", 256F, 3, Color.white, 256F, 2400F, 100F);
                 system.addRingBand(star, "misc", "rings1", 256F, 2, Color.white, 360F, 3500F, 130F);
                 system.addRingBand(star, "misc", "rings2", 256F, 3, Color.white, 456F, 2800F, 80F);
                 
                            //asteroid belts
                system.addAsteroidBelt(star, 75, 2000, 256, 600, 100);
		system.addAsteroidBelt(star, 150, 1500, 1000, 400, 830);
                system.addAsteroidBelt(star, 300, 3000, 2000, 200, 365);
                 
                 SectorEntityToken ring = system.addTerrain("ring", new com.fs.starfarer.api.impl.campaign.terrain.BaseRingTerrain.RingParams(3006F, 2200F, null, "Rock Dust")); 
                 ring.setCircularOrbit(star, 0.0F, 0.0F, 100F); 
                
                
                
                
		/*
		 * addPlanet() parameters:
		 * 1. What the planet orbits (orbit is always circular)
		 * 2. Name
		 * 3. Planet type id in planets.json
		 * 4. Starting angle in orbit, i.e. 0 = to the right of the star
		 * 5. Planet radius, pixels at default zoom
		 * 6. Orbit radius, pixels at default zoom
		 * 7. Days it takes to complete an orbit. 1 day = 10 seconds.
		 */
		
			
                    //brother planet
                PlanetAPI rock1 = system.addPlanet("viymese", star, "Viymese", "frozen", 90, 130, 4000, 365);
                rock1.setCustomDescriptionId("planet_viymese");
                    //gassy planet
                PlanetAPI rock2 = system.addPlanet("congite", star, "Congite", "gas_giant", 270, 400, 6000, 365);
		rock2.setCustomDescriptionId("planet_congite");
                
                //RANGUS   
                
                PlanetAPI rock2a = system.addPlanet("rangus", star, "Rangus", "arid", 270, 130, 4600, 365);
			rock2a.setCustomDescriptionId("planet_rangus");
			rock2a.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "sindria"));
			rock2a.getSpec().setGlowColor(new Color(235,245,255,255));
			rock2a.getSpec().setUseReverseLightForGlow(true);
			rock2a.applySpecChanges();
			rock2a.setInteractionImage("illustrations", "industrial_megafacility");
		
				system.addRingBand(rock2, "misc", "rings1", 256f, 2, Color.white, 256f, 1000, 40f);
				system.addAsteroidBelt(rock2, 20, 1000, 128, 40, 80);
                
                
                
                SectorEntityToken rock_station = system.addCustomEntity("rock_station", " Rock Citadel", "station_side02", "metelson");
			rock_station.setCircularOrbitPointingDown(system.getEntityById("rock"), 90, 600, 45);		
			rock_station.setCustomDescriptionId("rock_station");
			rock_station.setInteractionImage("illustrations", "hound_hangar");
                
                
                //Pirate Planet
                PlanetAPI rock3 = system.addPlanet("pebble", star, "Pebble", "barren",   280, 50, 12000, 650);
			rock3.setCustomDescriptionId("planet_Pebble");
			rock3.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "sindria"));
			rock3.getSpec().setGlowColor(new Color(235,245,255,255));
			rock3.getSpec().setUseReverseLightForGlow(true);
			rock3.applySpecChanges();
			rock3.setInteractionImage("illustrations", "pirate_station");
		                
                
                //jumpoints to be had
                JumpPointAPI jumpPoint = Global.getFactory().createJumpPoint("congite_passage","Congite Passage");
		OrbitAPI orbit = Global.getFactory().createCircularOrbit(rock2a, 0, 2200, 100);
			jumpPoint.setOrbit(orbit);	
			jumpPoint.setRelatedPlanet(rock2a);
			jumpPoint.setStandardWormholeToHyperspaceVisual();
			system.addEntity(jumpPoint);
                
                
                		// generates hyperspace destinations for in-system jump points
		system.autogenerateHyperspaceJumpPoints(true, true);
        
                
                SectorEntityToken relay = system.addCustomEntity("rock_relay", // unique id
				 "Rock Relay", // name - if null, defaultName from custom_entities.json will be used
				 "comm_relay", // type of object, defined in custom_entities.json
				 "metelson"); // faction
		relay.setCircularOrbit(system.getEntityById("rock"), 90, 1200, 45);
                
                
                
     

                   
    }
		
	private void initStationCargo(SectorEntityToken station) {
		CargoAPI cargo = station.getCargo();
		addRandomWeapons(cargo, 5);
		
		cargo.addCrew(CrewXPLevel.VETERAN, 20);
		cargo.addCrew(CrewXPLevel.REGULAR, 500);
		cargo.addMarines(200);
		cargo.addSupplies(1000);
		cargo.addFuel(500);
		
		cargo.getMothballedShips().addFleetMember(Global.getFactory().createFleetMember(FleetMemberType.SHIP, "crig_Hull"));
		cargo.getMothballedShips().addFleetMember(Global.getFactory().createFleetMember(FleetMemberType.SHIP, "ox_Hull"));
		cargo.getMothballedShips().addFleetMember(Global.getFactory().createFleetMember(FleetMemberType.FIGHTER_WING, "gladius_wing"));
		cargo.getMothballedShips().addFleetMember(Global.getFactory().createFleetMember(FleetMemberType.FIGHTER_WING, "gladius_wing"));
	}
	
	private void addRandomWeapons(CargoAPI cargo, int count) {
		List weaponIds = Global.getSector().getAllWeaponIds();
		for (int i = 0; i < count; i++) {
			String weaponId = (String) weaponIds.get((int) (weaponIds.size() * Math.random()));
			int quantity = (int)(Math.random() * 4f + 2f);
			cargo.addWeapons(weaponId, quantity);
		}
	}
	
}
