package data.scripts.world.systems;

import com.fs.starfarer.api.campaign.*;
import java.util.ArrayList;
import java.util.Arrays;

// Referenced classes of package data.scripts.world.systems:
//            Metelson_markets

public class metelsonValhalla
{
    public void generate(SectorAPI sector)
    {
        StarSystemAPI system = sector.getStarSystem("Valhalla");
        SectorEntityToken MIoutpost = system.addCustomEntity("metelsonCorvus", "MI Mining-Post", "station_side04", "metelson");
        MIoutpost.setCircularOrbit(system.getEntityById("ragnar"), 45 + 240, 1400, 50);
        MIoutpost.setCustomDescriptionId(null);
        com.fs.starfarer.api.campaign.econ.MarketAPI MIoutpost1 =
        Metelson_markets.addMarketplace("metelson", MIoutpost, null, "MI Mining-Post", 3, new ArrayList(Arrays.asList(new String[]
        {
            			"shipbreaking_center",
				"free_market",	
				"outpost",
				"ore_complex", "ore_complex", "ore_complex", 
				"orbital_station",
				"population_1",
        }
        )), new ArrayList(Arrays.asList(new String[] {
            "open_market", "black_market", "storage"
        })), 0.2F);
    }
}
