package data.missions.metelson_vs_all;

import com.fs.starfarer.api.mission.MissionDefinitionAPI;
import data.missions.BaseRandomMIMissionDefinition;

public class MissionDefinition extends BaseRandomMIMissionDefinition
{
    @Override
    public void defineMission(MissionDefinitionAPI api)
    {
        chooseFactions("metelson", null);
        super.defineMission(api);
    }
}