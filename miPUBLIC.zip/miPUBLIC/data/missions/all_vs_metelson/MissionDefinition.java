package data.missions.all_vs_metelson;

import com.fs.starfarer.api.mission.MissionDefinitionAPI;
import data.missions.BaseRandomMIMissionDefinition;

public class MissionDefinition extends BaseRandomMIMissionDefinition
{
    @Override
    public void defineMission(MissionDefinitionAPI api)
    {
        chooseFactions(null, "metelson");
        super.defineMission(api);
    }
}