package data.hullmods;

import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.combat.HullModEffect;
import com.fs.starfarer.api.combat.HullModFleetEffect;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class mi_MiRepairGantry implements HullModEffect, HullModFleetEffect {

    public static final String HULLMOD_ID = "mi_MiRepairGantry";
    public static final String STAT_MOD_ID = "mi_MiRepairGantry_repair_bonus";
    public static final float REPAIR_RATE_BONUS = 15f;

    static final Set<HullSize> EXCLUE_LIST = new HashSet<>();

    static {
        EXCLUE_LIST.add(HullSize.FIGHTER);
        EXCLUE_LIST.add(HullSize.FRIGATE);
    }

    public mi_MiRepairGantry() {
    }

    @Override
    public void advanceInCampaign(FleetMemberAPI member, float amount) {
    }

    @Override
    public void advanceInCombat(ShipAPI ship, float amount) {
    }

    @Override
    public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
    }

    @Override
    public void applyEffectsBeforeShipCreation(ShipAPI.HullSize hullSize, MutableShipStatsAPI stats, String id) {
    }

    @Override
    public boolean isApplicableToShip(ShipAPI ship) {
        return ship.getHullSpec().getHullId().startsWith("mi_");
    }

    @Override
    public String getDescriptionParam(int index, ShipAPI.HullSize hullSize) {
        if (index == 0) {
            return "" + (int) REPAIR_RATE_BONUS;
        }
        return null;
    }

    @Override
    public void advanceInCampaign(CampaignFleetAPI fleet) {

    }

    @Override
    public void onFleetSync(CampaignFleetAPI fleet) {
        List<FleetMemberAPI> rigs = new ArrayList<>();
        List<FleetMemberAPI> members = fleet.getFleetData().getMembersListCopy();
        for (FleetMemberAPI member : members) {
            if (member.isMothballed() || !member.canBeDeployedForCombat()) {
                continue;
            }
            for (String modId : member.getVariant().getHullMods()) {
                if (HULLMOD_ID.equals(modId)) {
                    rigs.add(member);
                }
            }
        }

        int index = 0;
        List<FleetMemberAPI> assisted = new ArrayList<>();
        for (FleetMemberAPI rig : rigs) {
            for (int i = index; i < members.size(); i++) {
                FleetMemberAPI member = members.get(i);
                if (rig == member) {
                    continue;
                }
                if (!member.canBeRepaired()) {
                    continue;
                }
                if (!member.needsRepairs()) {
                    continue;
                }
                if (EXCLUE_LIST.contains(member.getHullSpec().getHullSize())) {
                    continue;
                }

                member.getStats().getRepairRatePercentPerDay().modifyPercent(STAT_MOD_ID, REPAIR_RATE_BONUS);
                index = i + 1;
                assisted.add(member);
                break;
            }
        }

        for (FleetMemberAPI member : members) {
            if (!assisted.contains(member)) {
                member.getStats().getRepairRatePercentPerDay().unmodify(STAT_MOD_ID);
            }
        }
    }
}
