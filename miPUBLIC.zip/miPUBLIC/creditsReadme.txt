

Standard information and "legalities"
============================================
This Read me is to inform you that **the mod is provided as is**. The mod will be updated as I see fit and I can help with small bugs. If an older edition of the mod is requested I can only garuntee what I have put together from 0.7 upwards. Older editions have been lost or deleted. Otherwise it is standard stuff that is touted on the fourms. Give credit were due, do not use my work without permission and you may edit it for *!*personal use only*!*

--Azmond


============================================


Credits
============================================
:***:Main team:***:
Azmond-- Head Development, coder, writer, and graphics designer
Viymese-- co-developer, writer, ideas, and inital coder

:!*!: Special thanks to :!*!:
Alex-- For making a game I truly and utterly have loved modding for.
David-- For being insightfull, polite, and helpfull more than you may have known.
Mesotronik-- Code assitance, grpahic editation, editing, proof-reading, general advice and assitance

:**:Others of note and credit to be given:**:
Dark Revenant-- inital help setting up for when I first begun modding
Deathfly-- Code assitance, first ship-systems, first help given to mod production, and general helpfullness
Helmut-- Graphics assistance, sprite creation/critique and advice
Tartiflette-- Graphics assistance and advice


Finally, thank you to those who play this Mod and those who have commented on the thread.  Without your help, comments, and knowing/Unknowing encouragement; I would have made little in the way of progress and may've stopped my idea altogether.

Thank you for Downloading Metelson Industries. Enjoy the rocks with what riches you may find in your flying spuds.